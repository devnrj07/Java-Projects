package com.dao;

import com.Bean.Form;

public interface FormDao {

	  static void Register(Form formbean) {}
	  static void Display() {}
	  static void Update(Form formbean) {}
	
}
