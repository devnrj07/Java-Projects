package com.niit.model;

public class Employee {

	private int empId;
	private String empname;
	private double salary;
	private Project proj;
	/**
	 * @return the empId
	 */
	public int getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	/**
	 * @return the empname
	 */
	public String getEmpname() {
		return empname;
	}
	/**
	 * @param empname the empname to set
	 */
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empname=" + empname + ", salary=" + salary + "]";
	}
	
	
	public void display() {
		System.out.println(" EmpId "+ empId);
		System.out.println("Employee Name "+empname);
		System.out.println(" Salary "+salary);
		proj.display();
		
	}
	/**
	 * @return the proj
	 */
	public Project getProj() {
		return proj;
	}
	/**
	 * @param proj the proj to set
	 */
	public void setProj(Project proj) {
		this.proj = proj;
	}
	
	
}
