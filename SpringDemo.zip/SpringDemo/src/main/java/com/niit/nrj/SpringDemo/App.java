package com.niit.nrj.SpringDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.niit.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello to Spring " );
        
        ApplicationContext ctx;
        ctx= new ClassPathXmlApplicationContext("employee.xml");
        Employee emp=ctx.getBean("emp1", Employee.class);
        
       // emp=new Emplyee();
        //System.out.println(emp);
        
        emp.display();
    }
}
